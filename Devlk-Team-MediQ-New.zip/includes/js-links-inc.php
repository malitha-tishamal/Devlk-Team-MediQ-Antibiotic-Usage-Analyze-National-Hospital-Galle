<!-- Vendor JS Files -->
<script src="<?php echo $base_url; ?>assets/js/jquery.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/chart.js/chart.umd.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/echarts/echarts.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/quill/quill.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/tinymce/tinymce.min.js"></script>
<script src="<?php echo $base_url; ?>assets/vendor/php-email-form/validate.js"></script>
<script src="<?php echo $base_url; ?>assets/js/alert-toast.js"></script>

<!-- Utils JS File -->
<script src="<?php echo $base_url; ?>assets/js/utils.js"></script>

<!-- Template Main JS File -->
<script src="<?php echo $base_url; ?>assets/js/main.js"></script>