# mediq
Project MediQ

# Cloning this Repo
\* Use GitHub Desktop to Clone and Working with this Repo.<br/>

\* You Don't need to make a folder for clone this repo.</br>
<strong>
Clone this to:</br>
&emsp;&emsp; for Xampp Users -> C:\xampp\htdocs</br>
&emsp;&emsp; for Wamp Users -> C:\wamp\www</br>
</strong>

# Dtabase Setup
*You need to make a database name like <strong>mediq_db</strong> for open this project in your localhost.*<br />
Localhost Database Name = <strong>mediq_db</strong><br /><br />
   
# Attention to these things
<strong>* Before start the works, you have to pull the project.</strong><br />
<strong>* Don't edit codes, without asking from @malitha.</strong><br />

# Best Practices
\* You have to name custom css classes like this -> <strong>my-heading </strong><br />
\* You have to name custom ids like this -><strong> idOne </strong><br />
\* When naming functions, use a name taht describes what the function does -><strong> showAntibioticAvailability() </strong><br />
