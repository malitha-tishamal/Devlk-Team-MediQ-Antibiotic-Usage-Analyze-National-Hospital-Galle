<?php
session_start();
require_once 'includes/db-conn.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Handle date filter
$filter_date = isset($_POST['filter_date']) ? $_POST['filter_date'] : date('Y-m-d');
$sql = "SELECT * FROM returns WHERE DATE(return_time) = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $filter_date);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Antibiotic Return Details - Mediq</title>

  <?php include_once("includes/css-links-inc.php"); ?>
</head>

<body>
  <?php include_once("includes/header.php"); ?>
  <?php include_once("includes/user-sidebar.php"); ?>

  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Return Details</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Pages</li>
          <li class="breadcrumb-item active">Antibiotic Return Details</li>
        </ol>
      </nav>
    </div>

    <section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Antibiotic Return Details</h5>

              <!-- Date Filter Form -->
              <form method="POST" class="mb-3">
                <div class="d-flex">
                  <label for="filter_date">Select Date: &nbsp;&nbsp;&nbsp;</label>
                  <input type="date" name="filter_date" id="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>" class="form-control w-25">
                  &nbsp;&nbsp;
                  <button type="submit" class="btn btn-primary">Filter</button>
                </div>
              </form>

              <!-- Table with return data -->
              <table class="table datatable">
                <thead class="align-middle text-center">
                  <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">Antibiotic Name</th>
                    <th class="text-center">Dosage</th>
                    <th class="text-center">Item Count</th>
                    <th class="text-center">Ward Name</th>
                    <th class="text-center">Stock Type</th>
                    <th class="text-center">Route Type</th>
                    <th class="text-center">Book Number</th>
                    <th class="text-center">Page Number</th>
                    <th class="text-center">Return Time</th>
                    <th class="text-center">User</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                          echo "<tr>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['id']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['antibiotic_name']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['dosage']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['item_count']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['ward_name']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['type']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['ant_type']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['book_number']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['page_number']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['return_time']) . "</td>";
                          echo "<td class='text-center'>" . htmlspecialchars($row['system_name']) . "</td>";
                          echo "</tr>";
                      }
                  } else {
                      echo "<tr><td colspan='11' class='text-center'>No antibiotic returns found for this date.</td></tr>";
                  }
                  ?>
                </tbody>
              </table>
              <!-- End Table with return data -->

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <?php include_once("includes/footer.php"); ?>
  <?php include_once("includes/js-links-inc.php"); ?>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
</body>
</html>

<?php
$conn->close();
?>
